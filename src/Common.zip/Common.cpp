#include "Common.h"

Common::Common()
{
}
