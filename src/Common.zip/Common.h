#ifndef COMMON_H
#define COMMON_H

#include "common_global.h"
class COMMONSHARED_EXPORT Common
{

public:
    Common();
};

#endif // COMMON_H
