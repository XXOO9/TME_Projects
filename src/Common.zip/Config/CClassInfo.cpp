#include "CClassInfo.h"

CClassInfo::CClassInfo()
{

}
