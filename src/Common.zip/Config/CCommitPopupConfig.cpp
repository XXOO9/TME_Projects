#include "CCommitPopupConfig.h"

CCommitPopupConfig::CCommitPopupConfig()
{

}
