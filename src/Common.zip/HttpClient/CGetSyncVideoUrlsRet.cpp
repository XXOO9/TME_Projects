﻿#include "CGetSyncVideoUrlsRet.h"

CGetSyncVideoUrlsRet::CGetSyncVideoUrlsRet() : CAbstractResult ()
{

}

CGetSyncVideoUrlsRet::~CGetSyncVideoUrlsRet()
{

}
