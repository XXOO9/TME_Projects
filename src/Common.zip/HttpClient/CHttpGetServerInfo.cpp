﻿#include "CHttpGetServerInfo.h"

CHttpGetServerInfo::CHttpGetServerInfo()
{

}

CHttpGetServerInfo::~CHttpGetServerInfo()
{

}

void CHttpGetServerInfo::httpRequest()
{

}

void CHttpGetServerInfo::onNewReplyAvailable(QNetworkReply *pReply)
{

}

void CHttpGetServerInfo::onTimeoutHandler()
{

}

void CHttpGetServerInfo::initConfig()
{

}

bool CHttpGetServerInfo::parseJson()
{
    return true;
}

bool CHttpGetServerInfo::isParameterEmpty()
{
    return true;
}
