#include "CHttpUploadInfos.h"

CHttpUploadInfos::CHttpUploadInfos()
{

}
