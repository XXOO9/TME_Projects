﻿#include "CQueryCommonHistoryRet.h"

CQueryCommonHistoryRet::CQueryCommonHistoryRet()
{

}

CQueryCommonHistoryRet::~CQueryCommonHistoryRet()
{

}
