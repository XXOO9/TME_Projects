﻿#include "CSyncClassInfoRet.h"

CSyncClassInfoRet::CSyncClassInfoRet() : CAbstractResult ()
{

}

CSyncClassInfoRet::~CSyncClassInfoRet()
{

}
