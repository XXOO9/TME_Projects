﻿#include "CSyncScoreStdRet.h"

CSyncScoreStdRet::CSyncScoreStdRet() : CAbstractResult ()
{

}

CSyncScoreStdRet::~CSyncScoreStdRet()
{

}
