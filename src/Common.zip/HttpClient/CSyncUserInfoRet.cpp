﻿#include "CSyncUserInfoRet.h"

CSyncUserInfoRet::CSyncUserInfoRet() : CAbstractResult()
{

}

CSyncUserInfoRet::~CSyncUserInfoRet()
{

}
