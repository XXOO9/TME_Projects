﻿#include "CUserIdentifyRet.h"

CUserIdentifyRet::CUserIdentifyRet() : CAbstractResult ()
{

}

CUserIdentifyRet::~CUserIdentifyRet()
{

}
