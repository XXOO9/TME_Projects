#ifndef IIMAGEPROBASIC_H
#define IIMAGEPROBASIC_H


class IImageProcessBasic
{
public:
    IImageProcessBasic();
};

#endif // IIMAGEPROBASIC_H
