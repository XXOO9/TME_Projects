/****************************************************************************
** Meta object code from reading C++ file 'CHttpConnection.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "CHttpConnection.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CHttpConnection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_HttpConnection_t {
    QByteArrayData data[8];
    char stringdata0[143];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_HttpConnection_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_HttpConnection_t qt_meta_stringdata_HttpConnection = {
    {
QT_MOC_LITERAL(0, 0, 14), // "HttpConnection"
QT_MOC_LITERAL(1, 15, 21), // "STEHttpConnectionType"
QT_MOC_LITERAL(2, 37, 15), // "POST_UPLOADFILE"
QT_MOC_LITERAL(3, 53, 14), // "POST_PARAMETER"
QT_MOC_LITERAL(4, 68, 18), // "POST_PARAMETERWAIT"
QT_MOC_LITERAL(5, 87, 17), // "GET_WITHPARAMETER"
QT_MOC_LITERAL(6, 105, 20), // "GET_WITHOUTPARAMETER"
QT_MOC_LITERAL(7, 126, 16) // "GET_DOWNLOADFILE"

    },
    "HttpConnection\0STEHttpConnectionType\0"
    "POST_UPLOADFILE\0POST_PARAMETER\0"
    "POST_PARAMETERWAIT\0GET_WITHPARAMETER\0"
    "GET_WITHOUTPARAMETER\0GET_DOWNLOADFILE"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_HttpConnection[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, alias, flags, count, data
       1,    1, 0x0,    6,   19,

 // enum data: key, value
       2, uint(HttpConnection::POST_UPLOADFILE),
       3, uint(HttpConnection::POST_PARAMETER),
       4, uint(HttpConnection::POST_PARAMETERWAIT),
       5, uint(HttpConnection::GET_WITHPARAMETER),
       6, uint(HttpConnection::GET_WITHOUTPARAMETER),
       7, uint(HttpConnection::GET_DOWNLOADFILE),

       0        // eod
};

void HttpConnection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject HttpConnection::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_HttpConnection.data,
    qt_meta_data_HttpConnection,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *HttpConnection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *HttpConnection::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_HttpConnection.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int HttpConnection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
