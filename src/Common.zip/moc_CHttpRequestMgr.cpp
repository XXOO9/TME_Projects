/****************************************************************************
** Meta object code from reading C++ file 'CHttpRequestMgr.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "HttpClient/CHttpRequestMgr.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'CHttpRequestMgr.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_CHttpRequestMgr_t {
    QByteArrayData data[133];
    char stringdata0[2901];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_CHttpRequestMgr_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_CHttpRequestMgr_t qt_meta_stringdata_CHttpRequestMgr = {
    {
QT_MOC_LITERAL(0, 0, 15), // "CHttpRequestMgr"
QT_MOC_LITERAL(1, 16, 25), // "sigGetSampleVideoFinished"
QT_MOC_LITERAL(2, 42, 0), // ""
QT_MOC_LITERAL(3, 43, 2), // "ok"
QT_MOC_LITERAL(4, 46, 23), // "sigSyncScoreStdFinished"
QT_MOC_LITERAL(5, 70, 23), // "sigSyncUserInfoFinished"
QT_MOC_LITERAL(6, 94, 24), // "sigSyncClassInfoFinished"
QT_MOC_LITERAL(7, 119, 23), // "sigUserIdentifyFinished"
QT_MOC_LITERAL(8, 143, 20), // "sigHeartBeatFinished"
QT_MOC_LITERAL(9, 164, 20), // "sigUploadCommonScore"
QT_MOC_LITERAL(10, 185, 4), // "data"
QT_MOC_LITERAL(11, 190, 18), // "sigUploadBodyScore"
QT_MOC_LITERAL(12, 209, 22), // "sigUploadEyeSightScore"
QT_MOC_LITERAL(13, 232, 29), // "sigTouristUsageRecordFinished"
QT_MOC_LITERAL(14, 262, 12), // "netWorkState"
QT_MOC_LITERAL(15, 275, 7), // "retCode"
QT_MOC_LITERAL(16, 283, 24), // "sigCommitPrograssChanged"
QT_MOC_LITERAL(17, 308, 13), // "commitPersent"
QT_MOC_LITERAL(18, 322, 17), // "sigSyncLocalScore"
QT_MOC_LITERAL(19, 340, 6), // "userId"
QT_MOC_LITERAL(20, 347, 9), // "timeStmap"
QT_MOC_LITERAL(21, 357, 8), // "testItem"
QT_MOC_LITERAL(22, 366, 9), // "errorCode"
QT_MOC_LITERAL(23, 376, 10), // "syncSucess"
QT_MOC_LITERAL(24, 387, 28), // "sigQueryHistoryScoreFinished"
QT_MOC_LITERAL(25, 416, 33), // "sigUploadMultiCommonScoreFini..."
QT_MOC_LITERAL(26, 450, 28), // "QVector<CMultiUploadRetInfo>"
QT_MOC_LITERAL(27, 479, 23), // "vecCommonUploadRetInfos"
QT_MOC_LITERAL(28, 503, 31), // "sigUploadMultiBodyScoreFinished"
QT_MOC_LITERAL(29, 535, 21), // "vecBodyUploadRetInfos"
QT_MOC_LITERAL(30, 557, 35), // "sigUploadMultiEyeSightScoreFi..."
QT_MOC_LITERAL(31, 593, 25), // "vecEyeSightUploadRetInfos"
QT_MOC_LITERAL(32, 619, 29), // "sigSendMultiHeartBeatFinished"
QT_MOC_LITERAL(33, 649, 31), // "sigSyncMultiLocalScoresFinished"
QT_MOC_LITERAL(34, 681, 19), // "totalSyncScoreInfos"
QT_MOC_LITERAL(35, 701, 29), // "insideSigInitMemberConnection"
QT_MOC_LITERAL(36, 731, 21), // "insideSigGetVideoUrls"
QT_MOC_LITERAL(37, 753, 9), // "timeStamp"
QT_MOC_LITERAL(38, 763, 22), // "insideSigSendHeartBeat"
QT_MOC_LITERAL(39, 786, 6), // "status"
QT_MOC_LITERAL(40, 793, 7), // "battery"
QT_MOC_LITERAL(41, 801, 7), // "devCode"
QT_MOC_LITERAL(42, 809, 7), // "devType"
QT_MOC_LITERAL(43, 817, 21), // "insideSigSyncScoreStd"
QT_MOC_LITERAL(44, 839, 21), // "insideSigSyncUserInfo"
QT_MOC_LITERAL(45, 861, 14), // "faceEngineType"
QT_MOC_LITERAL(46, 876, 22), // "insideSigSyncClassInfo"
QT_MOC_LITERAL(47, 899, 21), // "insideSigUserIdentify"
QT_MOC_LITERAL(48, 921, 11), // "faceFeature"
QT_MOC_LITERAL(49, 933, 10), // "faceEngine"
QT_MOC_LITERAL(50, 944, 6), // "cardNo"
QT_MOC_LITERAL(51, 951, 4), // "code"
QT_MOC_LITERAL(52, 956, 26), // "insideSigUploadCommonScore"
QT_MOC_LITERAL(53, 983, 34), // "insideSigUploadCommonScoreByV..."
QT_MOC_LITERAL(54, 1018, 24), // "insideSigUploadBodyScore"
QT_MOC_LITERAL(55, 1043, 28), // "insideSigUploadEyeSightScore"
QT_MOC_LITERAL(56, 1072, 26), // "insideSigToutisUsageRecord"
QT_MOC_LITERAL(57, 1099, 18), // "insideSigStartAuto"
QT_MOC_LITERAL(58, 1118, 33), // "insideSigStartAutoUploadBodyS..."
QT_MOC_LITERAL(59, 1152, 31), // "insideSigStartAutoEyesightScore"
QT_MOC_LITERAL(60, 1184, 23), // "insideSigSyncLocalScore"
QT_MOC_LITERAL(61, 1208, 26), // "insideSigQueryHistoryScore"
QT_MOC_LITERAL(62, 1235, 6), // "params"
QT_MOC_LITERAL(63, 1242, 32), // "insideSigUploadMultiCommonScores"
QT_MOC_LITERAL(64, 1275, 4), // "list"
QT_MOC_LITERAL(65, 1280, 30), // "insideSigUploadMultiBodyScores"
QT_MOC_LITERAL(66, 1311, 34), // "insideSigUploadMultiEyeSightS..."
QT_MOC_LITERAL(67, 1346, 27), // "insideSigSendMultiHeartBeat"
QT_MOC_LITERAL(68, 1374, 29), // "insideSigSyncMultiLcoalScores"
QT_MOC_LITERAL(69, 1404, 10), // "commonList"
QT_MOC_LITERAL(70, 1415, 8), // "bodyList"
QT_MOC_LITERAL(71, 1424, 12), // "eyeSightList"
QT_MOC_LITERAL(72, 1437, 28), // "insideSigStartGetServerToken"
QT_MOC_LITERAL(73, 1466, 12), // "loginInfoMap"
QT_MOC_LITERAL(74, 1479, 21), // "onStartGetServerToken"
QT_MOC_LITERAL(75, 1501, 25), // "onUploadMultiCommonScores"
QT_MOC_LITERAL(76, 1527, 23), // "onUploadMultiBodyScores"
QT_MOC_LITERAL(77, 1551, 27), // "onUploadMultiEyeSightScores"
QT_MOC_LITERAL(78, 1579, 20), // "onSendMultiHeartBeat"
QT_MOC_LITERAL(79, 1600, 22), // "onSyncMultiLocalScores"
QT_MOC_LITERAL(80, 1623, 20), // "onGetSampleVideoUrls"
QT_MOC_LITERAL(81, 1644, 19), // "onSyncScoreStandard"
QT_MOC_LITERAL(82, 1664, 14), // "onSyncUserInfo"
QT_MOC_LITERAL(83, 1679, 15), // "onSyncClassInfo"
QT_MOC_LITERAL(84, 1695, 14), // "onUserIdentify"
QT_MOC_LITERAL(85, 1710, 15), // "onSendHeartBeat"
QT_MOC_LITERAL(86, 1726, 19), // "onUploadCommonScore"
QT_MOC_LITERAL(87, 1746, 27), // "onUploadCommonScoreByVector"
QT_MOC_LITERAL(88, 1774, 17), // "onUpLoadBodyScore"
QT_MOC_LITERAL(89, 1792, 21), // "onUpLoadEyeSightScore"
QT_MOC_LITERAL(90, 1814, 20), // "onTouristUsageRecord"
QT_MOC_LITERAL(91, 1835, 14), // "onTimerTimeout"
QT_MOC_LITERAL(92, 1850, 12), // "onAutoUpload"
QT_MOC_LITERAL(93, 1863, 21), // "onAutoUploadBodyScore"
QT_MOC_LITERAL(94, 1885, 25), // "onAutoUploadEyesightScore"
QT_MOC_LITERAL(95, 1911, 14), // "onUploadCommon"
QT_MOC_LITERAL(96, 1926, 12), // "onUploadBody"
QT_MOC_LITERAL(97, 1939, 16), // "onUploadEyesight"
QT_MOC_LITERAL(98, 1956, 17), // "onSyncLocalScores"
QT_MOC_LITERAL(99, 1974, 19), // "onQueryHistoryScore"
QT_MOC_LITERAL(100, 1994, 28), // "onInitInsideMemberConnection"
QT_MOC_LITERAL(101, 2023, 32), // "onSyncSingleScoreResultAvailable"
QT_MOC_LITERAL(102, 2056, 10), // "uploadType"
QT_MOC_LITERAL(103, 2067, 34), // "onQueryHistoryScoreResultAvai..."
QT_MOC_LITERAL(104, 2102, 22), // "getHttpQueryRequestObj"
QT_MOC_LITERAL(105, 2125, 23), // "CHttpQueryHistoryScore*"
QT_MOC_LITERAL(106, 2149, 28), // "getUploadMultiCommonScoreObj"
QT_MOC_LITERAL(107, 2178, 28), // "CHttpUpLoadMultiCommonScore*"
QT_MOC_LITERAL(108, 2207, 26), // "getUploadMultiBodyScoreObj"
QT_MOC_LITERAL(109, 2234, 27), // "CHttpUpLoadMultiBodyScores*"
QT_MOC_LITERAL(110, 2262, 30), // "getUploadMultiEyeSightScoreObj"
QT_MOC_LITERAL(111, 2293, 31), // "CHttpUpLoadMultiEyeSightScores*"
QT_MOC_LITERAL(112, 2325, 24), // "getSendMultiHeartBeatObj"
QT_MOC_LITERAL(113, 2350, 20), // "CHttpMultiHeartBeat*"
QT_MOC_LITERAL(114, 2371, 24), // "getPSyncMultiLocalScores"
QT_MOC_LITERAL(115, 2396, 26), // "CHttpSyncMultiLocalScores*"
QT_MOC_LITERAL(116, 2423, 24), // "onGetServerTokenFinished"
QT_MOC_LITERAL(117, 2448, 28), // "onGetSampleVideoUrlsFinished"
QT_MOC_LITERAL(118, 2477, 27), // "onSyncScoreStandardFinished"
QT_MOC_LITERAL(119, 2505, 22), // "onSyncUserInfoFinished"
QT_MOC_LITERAL(120, 2528, 23), // "onSyncClassInfoFinished"
QT_MOC_LITERAL(121, 2552, 22), // "onUserIdentifyFinished"
QT_MOC_LITERAL(122, 2575, 23), // "onHeartBeatSendFinished"
QT_MOC_LITERAL(123, 2599, 27), // "onUploadCommonScoreFinished"
QT_MOC_LITERAL(124, 2627, 25), // "onUploadBodyScoreFinished"
QT_MOC_LITERAL(125, 2653, 29), // "onUploadEyesightScoreFinished"
QT_MOC_LITERAL(126, 2683, 28), // "onTouristUsageRecordFinished"
QT_MOC_LITERAL(127, 2712, 32), // "onUploadMultiCommonScoreFinished"
QT_MOC_LITERAL(128, 2745, 30), // "onUploadMultiBodyScoreFinished"
QT_MOC_LITERAL(129, 2776, 34), // "onUploadMultiEyeSightScoreFin..."
QT_MOC_LITERAL(130, 2811, 28), // "onSendMultiHeartBeatFinished"
QT_MOC_LITERAL(131, 2840, 30), // "onSyncMultiLocalScoresFinished"
QT_MOC_LITERAL(132, 2871, 29) // "QVector<CMultiUploadRetInfo>&"

    },
    "CHttpRequestMgr\0sigGetSampleVideoFinished\0"
    "\0ok\0sigSyncScoreStdFinished\0"
    "sigSyncUserInfoFinished\0"
    "sigSyncClassInfoFinished\0"
    "sigUserIdentifyFinished\0sigHeartBeatFinished\0"
    "sigUploadCommonScore\0data\0sigUploadBodyScore\0"
    "sigUploadEyeSightScore\0"
    "sigTouristUsageRecordFinished\0"
    "netWorkState\0retCode\0sigCommitPrograssChanged\0"
    "commitPersent\0sigSyncLocalScore\0userId\0"
    "timeStmap\0testItem\0errorCode\0syncSucess\0"
    "sigQueryHistoryScoreFinished\0"
    "sigUploadMultiCommonScoreFinished\0"
    "QVector<CMultiUploadRetInfo>\0"
    "vecCommonUploadRetInfos\0"
    "sigUploadMultiBodyScoreFinished\0"
    "vecBodyUploadRetInfos\0"
    "sigUploadMultiEyeSightScoreFinished\0"
    "vecEyeSightUploadRetInfos\0"
    "sigSendMultiHeartBeatFinished\0"
    "sigSyncMultiLocalScoresFinished\0"
    "totalSyncScoreInfos\0insideSigInitMemberConnection\0"
    "insideSigGetVideoUrls\0timeStamp\0"
    "insideSigSendHeartBeat\0status\0battery\0"
    "devCode\0devType\0insideSigSyncScoreStd\0"
    "insideSigSyncUserInfo\0faceEngineType\0"
    "insideSigSyncClassInfo\0insideSigUserIdentify\0"
    "faceFeature\0faceEngine\0cardNo\0code\0"
    "insideSigUploadCommonScore\0"
    "insideSigUploadCommonScoreByVector\0"
    "insideSigUploadBodyScore\0"
    "insideSigUploadEyeSightScore\0"
    "insideSigToutisUsageRecord\0"
    "insideSigStartAuto\0insideSigStartAutoUploadBodyScore\0"
    "insideSigStartAutoEyesightScore\0"
    "insideSigSyncLocalScore\0"
    "insideSigQueryHistoryScore\0params\0"
    "insideSigUploadMultiCommonScores\0list\0"
    "insideSigUploadMultiBodyScores\0"
    "insideSigUploadMultiEyeSightScores\0"
    "insideSigSendMultiHeartBeat\0"
    "insideSigSyncMultiLcoalScores\0commonList\0"
    "bodyList\0eyeSightList\0"
    "insideSigStartGetServerToken\0loginInfoMap\0"
    "onStartGetServerToken\0onUploadMultiCommonScores\0"
    "onUploadMultiBodyScores\0"
    "onUploadMultiEyeSightScores\0"
    "onSendMultiHeartBeat\0onSyncMultiLocalScores\0"
    "onGetSampleVideoUrls\0onSyncScoreStandard\0"
    "onSyncUserInfo\0onSyncClassInfo\0"
    "onUserIdentify\0onSendHeartBeat\0"
    "onUploadCommonScore\0onUploadCommonScoreByVector\0"
    "onUpLoadBodyScore\0onUpLoadEyeSightScore\0"
    "onTouristUsageRecord\0onTimerTimeout\0"
    "onAutoUpload\0onAutoUploadBodyScore\0"
    "onAutoUploadEyesightScore\0onUploadCommon\0"
    "onUploadBody\0onUploadEyesight\0"
    "onSyncLocalScores\0onQueryHistoryScore\0"
    "onInitInsideMemberConnection\0"
    "onSyncSingleScoreResultAvailable\0"
    "uploadType\0onQueryHistoryScoreResultAvailable\0"
    "getHttpQueryRequestObj\0CHttpQueryHistoryScore*\0"
    "getUploadMultiCommonScoreObj\0"
    "CHttpUpLoadMultiCommonScore*\0"
    "getUploadMultiBodyScoreObj\0"
    "CHttpUpLoadMultiBodyScores*\0"
    "getUploadMultiEyeSightScoreObj\0"
    "CHttpUpLoadMultiEyeSightScores*\0"
    "getSendMultiHeartBeatObj\0CHttpMultiHeartBeat*\0"
    "getPSyncMultiLocalScores\0"
    "CHttpSyncMultiLocalScores*\0"
    "onGetServerTokenFinished\0"
    "onGetSampleVideoUrlsFinished\0"
    "onSyncScoreStandardFinished\0"
    "onSyncUserInfoFinished\0onSyncClassInfoFinished\0"
    "onUserIdentifyFinished\0onHeartBeatSendFinished\0"
    "onUploadCommonScoreFinished\0"
    "onUploadBodyScoreFinished\0"
    "onUploadEyesightScoreFinished\0"
    "onTouristUsageRecordFinished\0"
    "onUploadMultiCommonScoreFinished\0"
    "onUploadMultiBodyScoreFinished\0"
    "onUploadMultiEyeSightScoreFinished\0"
    "onSendMultiHeartBeatFinished\0"
    "onSyncMultiLocalScoresFinished\0"
    "QVector<CMultiUploadRetInfo>&"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_CHttpRequestMgr[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      97,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      41,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  499,    2, 0x06 /* Public */,
       4,    1,  502,    2, 0x06 /* Public */,
       5,    1,  505,    2, 0x06 /* Public */,
       6,    1,  508,    2, 0x06 /* Public */,
       7,    1,  511,    2, 0x06 /* Public */,
       8,    1,  514,    2, 0x06 /* Public */,
       9,    1,  517,    2, 0x06 /* Public */,
      11,    1,  520,    2, 0x06 /* Public */,
      12,    1,  523,    2, 0x06 /* Public */,
      13,    3,  526,    2, 0x06 /* Public */,
      16,    1,  533,    2, 0x06 /* Public */,
      18,    5,  536,    2, 0x06 /* Public */,
      24,    2,  547,    2, 0x06 /* Public */,
      25,    1,  552,    2, 0x06 /* Public */,
      28,    1,  555,    2, 0x06 /* Public */,
      30,    1,  558,    2, 0x06 /* Public */,
      32,    1,  561,    2, 0x06 /* Public */,
      33,    1,  564,    2, 0x06 /* Public */,
      35,    0,  567,    2, 0x06 /* Public */,
      36,    1,  568,    2, 0x06 /* Public */,
      38,    4,  571,    2, 0x06 /* Public */,
      43,    0,  580,    2, 0x06 /* Public */,
      44,    2,  581,    2, 0x06 /* Public */,
      46,    1,  586,    2, 0x06 /* Public */,
      47,    4,  589,    2, 0x06 /* Public */,
      52,    1,  598,    2, 0x06 /* Public */,
      53,    1,  601,    2, 0x06 /* Public */,
      54,    1,  604,    2, 0x06 /* Public */,
      55,    1,  607,    2, 0x06 /* Public */,
      56,    3,  610,    2, 0x06 /* Public */,
      57,    0,  617,    2, 0x06 /* Public */,
      58,    0,  618,    2, 0x06 /* Public */,
      59,    0,  619,    2, 0x06 /* Public */,
      60,    0,  620,    2, 0x06 /* Public */,
      61,    1,  621,    2, 0x06 /* Public */,
      63,    1,  624,    2, 0x06 /* Public */,
      65,    1,  627,    2, 0x06 /* Public */,
      66,    1,  630,    2, 0x06 /* Public */,
      67,    1,  633,    2, 0x06 /* Public */,
      68,    3,  636,    2, 0x06 /* Public */,
      72,    1,  643,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      74,    1,  646,    2, 0x0a /* Public */,
      75,    1,  649,    2, 0x0a /* Public */,
      76,    1,  652,    2, 0x0a /* Public */,
      77,    1,  655,    2, 0x0a /* Public */,
      78,    1,  658,    2, 0x0a /* Public */,
      79,    3,  661,    2, 0x0a /* Public */,
      80,    1,  668,    2, 0x0a /* Public */,
      81,    0,  671,    2, 0x0a /* Public */,
      82,    2,  672,    2, 0x0a /* Public */,
      82,    1,  677,    2, 0x2a /* Public | MethodCloned */,
      82,    0,  680,    2, 0x2a /* Public | MethodCloned */,
      83,    1,  681,    2, 0x0a /* Public */,
      83,    0,  684,    2, 0x2a /* Public | MethodCloned */,
      84,    4,  685,    2, 0x0a /* Public */,
      84,    3,  694,    2, 0x2a /* Public | MethodCloned */,
      84,    2,  701,    2, 0x2a /* Public | MethodCloned */,
      85,    4,  706,    2, 0x0a /* Public */,
      86,    1,  715,    2, 0x0a /* Public */,
      87,    1,  718,    2, 0x0a /* Public */,
      88,    1,  721,    2, 0x0a /* Public */,
      89,    1,  724,    2, 0x0a /* Public */,
      90,    3,  727,    2, 0x0a /* Public */,
      91,    0,  734,    2, 0x0a /* Public */,
      92,    0,  735,    2, 0x0a /* Public */,
      93,    0,  736,    2, 0x0a /* Public */,
      94,    0,  737,    2, 0x0a /* Public */,
      95,    0,  738,    2, 0x0a /* Public */,
      96,    0,  739,    2, 0x0a /* Public */,
      97,    0,  740,    2, 0x0a /* Public */,
      98,    0,  741,    2, 0x0a /* Public */,
      99,    1,  742,    2, 0x0a /* Public */,
     100,    0,  745,    2, 0x0a /* Public */,
     101,    2,  746,    2, 0x0a /* Public */,
     103,    1,  751,    2, 0x0a /* Public */,
     104,    0,  754,    2, 0x0a /* Public */,
     106,    0,  755,    2, 0x0a /* Public */,
     108,    0,  756,    2, 0x0a /* Public */,
     110,    0,  757,    2, 0x0a /* Public */,
     112,    0,  758,    2, 0x0a /* Public */,
     114,    0,  759,    2, 0x0a /* Public */,
     116,    1,  760,    2, 0x0a /* Public */,
     117,    1,  763,    2, 0x0a /* Public */,
     118,    1,  766,    2, 0x0a /* Public */,
     119,    1,  769,    2, 0x0a /* Public */,
     120,    1,  772,    2, 0x0a /* Public */,
     121,    1,  775,    2, 0x0a /* Public */,
     122,    1,  778,    2, 0x0a /* Public */,
     123,    1,  781,    2, 0x0a /* Public */,
     124,    1,  784,    2, 0x0a /* Public */,
     125,    1,  787,    2, 0x0a /* Public */,
     126,    1,  790,    2, 0x0a /* Public */,
     127,    1,  793,    2, 0x0a /* Public */,
     128,    1,  796,    2, 0x0a /* Public */,
     129,    1,  799,    2, 0x0a /* Public */,
     130,    1,  802,    2, 0x0a /* Public */,
     131,    1,  805,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::Bool, QMetaType::Bool, QMetaType::Int,    3,   14,   15,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QString, QMetaType::QString, QMetaType::Short, QMetaType::QString, QMetaType::Bool,   19,   20,   21,   22,   23,
    QMetaType::Void, QMetaType::Bool, QMetaType::QVariant,    3,   10,
    QMetaType::Void, 0x80000000 | 26,   27,
    QMetaType::Void, 0x80000000 | 26,   29,
    QMetaType::Void, 0x80000000 | 26,   31,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 26,   34,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::Short,   39,   40,   41,   42,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   37,   45,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::QString, QMetaType::QString,   48,   49,   50,   51,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::Short, QMetaType::QString,   41,   42,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QVariantMap,   62,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList, QMetaType::QVariantList, QMetaType::QVariantList,   69,   70,   71,
    QMetaType::Void, QMetaType::QVariantMap,   73,

 // slots: parameters
    QMetaType::Void, QMetaType::QVariantMap,   73,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList,   64,
    QMetaType::Void, QMetaType::QVariantList, QMetaType::QVariantList, QMetaType::QVariantList,   69,   70,   71,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   37,   49,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   37,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::QString, QMetaType::QString,   48,   49,   50,   51,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, QMetaType::QString,   48,   49,   50,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   48,   49,
    QMetaType::Void, QMetaType::Int, QMetaType::QString, QMetaType::QString, QMetaType::Short,   39,   40,   41,   42,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QVariant,   10,
    QMetaType::Void, QMetaType::QString, QMetaType::Short, QMetaType::QString,   41,   42,   37,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QVariantMap,   62,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QVariant, QMetaType::Int,   10,  102,
    QMetaType::Void, QMetaType::Bool,    3,
    0x80000000 | 105,
    0x80000000 | 107,
    0x80000000 | 109,
    0x80000000 | 111,
    0x80000000 | 113,
    0x80000000 | 115,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 132,   34,

       0        // eod
};

void CHttpRequestMgr::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<CHttpRequestMgr *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sigGetSampleVideoFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->sigSyncScoreStdFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->sigSyncUserInfoFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->sigSyncClassInfoFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->sigUserIdentifyFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->sigHeartBeatFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->sigUploadCommonScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 7: _t->sigUploadBodyScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 8: _t->sigUploadEyeSightScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 9: _t->sigTouristUsageRecordFinished((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3]))); break;
        case 10: _t->sigCommitPrograssChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 11: _t->sigSyncLocalScore((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< short(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< bool(*)>(_a[5]))); break;
        case 12: _t->sigQueryHistoryScoreFinished((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QVariant(*)>(_a[2]))); break;
        case 13: _t->sigUploadMultiCommonScoreFinished((*reinterpret_cast< QVector<CMultiUploadRetInfo>(*)>(_a[1]))); break;
        case 14: _t->sigUploadMultiBodyScoreFinished((*reinterpret_cast< QVector<CMultiUploadRetInfo>(*)>(_a[1]))); break;
        case 15: _t->sigUploadMultiEyeSightScoreFinished((*reinterpret_cast< QVector<CMultiUploadRetInfo>(*)>(_a[1]))); break;
        case 16: _t->sigSendMultiHeartBeatFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->sigSyncMultiLocalScoresFinished((*reinterpret_cast< QVector<CMultiUploadRetInfo>(*)>(_a[1]))); break;
        case 18: _t->insideSigInitMemberConnection(); break;
        case 19: _t->insideSigGetVideoUrls((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->insideSigSendHeartBeat((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< short(*)>(_a[4]))); break;
        case 21: _t->insideSigSyncScoreStd(); break;
        case 22: _t->insideSigSyncUserInfo((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 23: _t->insideSigSyncClassInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 24: _t->insideSigUserIdentify((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 25: _t->insideSigUploadCommonScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 26: _t->insideSigUploadCommonScoreByVector((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 27: _t->insideSigUploadBodyScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 28: _t->insideSigUploadEyeSightScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 29: _t->insideSigToutisUsageRecord((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< short(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 30: _t->insideSigStartAuto(); break;
        case 31: _t->insideSigStartAutoUploadBodyScore(); break;
        case 32: _t->insideSigStartAutoEyesightScore(); break;
        case 33: _t->insideSigSyncLocalScore(); break;
        case 34: _t->insideSigQueryHistoryScore((*reinterpret_cast< QVariantMap(*)>(_a[1]))); break;
        case 35: _t->insideSigUploadMultiCommonScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 36: _t->insideSigUploadMultiBodyScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 37: _t->insideSigUploadMultiEyeSightScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 38: _t->insideSigSendMultiHeartBeat((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 39: _t->insideSigSyncMultiLcoalScores((*reinterpret_cast< QVariantList(*)>(_a[1])),(*reinterpret_cast< QVariantList(*)>(_a[2])),(*reinterpret_cast< QVariantList(*)>(_a[3]))); break;
        case 40: _t->insideSigStartGetServerToken((*reinterpret_cast< const QVariantMap(*)>(_a[1]))); break;
        case 41: _t->onStartGetServerToken((*reinterpret_cast< const QVariantMap(*)>(_a[1]))); break;
        case 42: _t->onUploadMultiCommonScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 43: _t->onUploadMultiBodyScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 44: _t->onUploadMultiEyeSightScores((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 45: _t->onSendMultiHeartBeat((*reinterpret_cast< QVariantList(*)>(_a[1]))); break;
        case 46: _t->onSyncMultiLocalScores((*reinterpret_cast< QVariantList(*)>(_a[1])),(*reinterpret_cast< QVariantList(*)>(_a[2])),(*reinterpret_cast< QVariantList(*)>(_a[3]))); break;
        case 47: _t->onGetSampleVideoUrls((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 48: _t->onSyncScoreStandard(); break;
        case 49: _t->onSyncUserInfo((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 50: _t->onSyncUserInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 51: _t->onSyncUserInfo(); break;
        case 52: _t->onSyncClassInfo((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 53: _t->onSyncClassInfo(); break;
        case 54: _t->onUserIdentify((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 55: _t->onUserIdentify((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 56: _t->onUserIdentify((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 57: _t->onSendHeartBeat((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< short(*)>(_a[4]))); break;
        case 58: _t->onUploadCommonScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 59: _t->onUploadCommonScoreByVector((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 60: _t->onUpLoadBodyScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 61: _t->onUpLoadEyeSightScore((*reinterpret_cast< QVariant(*)>(_a[1]))); break;
        case 62: _t->onTouristUsageRecord((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< short(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3]))); break;
        case 63: _t->onTimerTimeout(); break;
        case 64: _t->onAutoUpload(); break;
        case 65: _t->onAutoUploadBodyScore(); break;
        case 66: _t->onAutoUploadEyesightScore(); break;
        case 67: _t->onUploadCommon(); break;
        case 68: _t->onUploadBody(); break;
        case 69: _t->onUploadEyesight(); break;
        case 70: _t->onSyncLocalScores(); break;
        case 71: _t->onQueryHistoryScore((*reinterpret_cast< QVariantMap(*)>(_a[1]))); break;
        case 72: _t->onInitInsideMemberConnection(); break;
        case 73: _t->onSyncSingleScoreResultAvailable((*reinterpret_cast< QVariant(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 74: _t->onQueryHistoryScoreResultAvailable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 75: { CHttpQueryHistoryScore* _r = _t->getHttpQueryRequestObj();
            if (_a[0]) *reinterpret_cast< CHttpQueryHistoryScore**>(_a[0]) = std::move(_r); }  break;
        case 76: { CHttpUpLoadMultiCommonScore* _r = _t->getUploadMultiCommonScoreObj();
            if (_a[0]) *reinterpret_cast< CHttpUpLoadMultiCommonScore**>(_a[0]) = std::move(_r); }  break;
        case 77: { CHttpUpLoadMultiBodyScores* _r = _t->getUploadMultiBodyScoreObj();
            if (_a[0]) *reinterpret_cast< CHttpUpLoadMultiBodyScores**>(_a[0]) = std::move(_r); }  break;
        case 78: { CHttpUpLoadMultiEyeSightScores* _r = _t->getUploadMultiEyeSightScoreObj();
            if (_a[0]) *reinterpret_cast< CHttpUpLoadMultiEyeSightScores**>(_a[0]) = std::move(_r); }  break;
        case 79: { CHttpMultiHeartBeat* _r = _t->getSendMultiHeartBeatObj();
            if (_a[0]) *reinterpret_cast< CHttpMultiHeartBeat**>(_a[0]) = std::move(_r); }  break;
        case 80: { CHttpSyncMultiLocalScores* _r = _t->getPSyncMultiLocalScores();
            if (_a[0]) *reinterpret_cast< CHttpSyncMultiLocalScores**>(_a[0]) = std::move(_r); }  break;
        case 81: _t->onGetServerTokenFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 82: _t->onGetSampleVideoUrlsFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 83: _t->onSyncScoreStandardFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 84: _t->onSyncUserInfoFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 85: _t->onSyncClassInfoFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 86: _t->onUserIdentifyFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 87: _t->onHeartBeatSendFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 88: _t->onUploadCommonScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 89: _t->onUploadBodyScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 90: _t->onUploadEyesightScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 91: _t->onTouristUsageRecordFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 92: _t->onUploadMultiCommonScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 93: _t->onUploadMultiBodyScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 94: _t->onUploadMultiEyeSightScoreFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 95: _t->onSendMultiHeartBeatFinished((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 96: _t->onSyncMultiLocalScoresFinished((*reinterpret_cast< QVector<CMultiUploadRetInfo>(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigGetSampleVideoFinished)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSyncScoreStdFinished)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSyncUserInfoFinished)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSyncClassInfoFinished)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUserIdentifyFinished)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigHeartBeatFinished)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadCommonScore)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadBodyScore)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadEyeSightScore)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool , bool , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigTouristUsageRecordFinished)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigCommitPrograssChanged)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString , QString , short , QString , bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSyncLocalScore)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool , QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigQueryHistoryScoreFinished)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVector<CMultiUploadRetInfo> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadMultiCommonScoreFinished)) {
                *result = 13;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVector<CMultiUploadRetInfo> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadMultiBodyScoreFinished)) {
                *result = 14;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVector<CMultiUploadRetInfo> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigUploadMultiEyeSightScoreFinished)) {
                *result = 15;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSendMultiHeartBeatFinished)) {
                *result = 16;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVector<CMultiUploadRetInfo> );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::sigSyncMultiLocalScoresFinished)) {
                *result = 17;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigInitMemberConnection)) {
                *result = 18;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigGetVideoUrls)) {
                *result = 19;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(int , QString , QString , short );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSendHeartBeat)) {
                *result = 20;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSyncScoreStd)) {
                *result = 21;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString , int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSyncUserInfo)) {
                *result = 22;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSyncClassInfo)) {
                *result = 23;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString , int , QString , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUserIdentify)) {
                *result = 24;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadCommonScore)) {
                *result = 25;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadCommonScoreByVector)) {
                *result = 26;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadBodyScore)) {
                *result = 27;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariant );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadEyeSightScore)) {
                *result = 28;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QString , short , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigToutisUsageRecord)) {
                *result = 29;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigStartAuto)) {
                *result = 30;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigStartAutoUploadBodyScore)) {
                *result = 31;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigStartAutoEyesightScore)) {
                *result = 32;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSyncLocalScore)) {
                *result = 33;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantMap );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigQueryHistoryScore)) {
                *result = 34;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadMultiCommonScores)) {
                *result = 35;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadMultiBodyScores)) {
                *result = 36;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigUploadMultiEyeSightScores)) {
                *result = 37;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSendMultiHeartBeat)) {
                *result = 38;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(QVariantList , QVariantList , QVariantList );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigSyncMultiLcoalScores)) {
                *result = 39;
                return;
            }
        }
        {
            using _t = void (CHttpRequestMgr::*)(const QVariantMap );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&CHttpRequestMgr::insideSigStartGetServerToken)) {
                *result = 40;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject CHttpRequestMgr::staticMetaObject = { {
    &QObject::staticMetaObject,
    qt_meta_stringdata_CHttpRequestMgr.data,
    qt_meta_data_CHttpRequestMgr,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *CHttpRequestMgr::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *CHttpRequestMgr::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_CHttpRequestMgr.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int CHttpRequestMgr::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 97)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 97;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 97)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 97;
    }
    return _id;
}

// SIGNAL 0
void CHttpRequestMgr::sigGetSampleVideoFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void CHttpRequestMgr::sigSyncScoreStdFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void CHttpRequestMgr::sigSyncUserInfoFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void CHttpRequestMgr::sigSyncClassInfoFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void CHttpRequestMgr::sigUserIdentifyFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void CHttpRequestMgr::sigHeartBeatFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void CHttpRequestMgr::sigUploadCommonScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void CHttpRequestMgr::sigUploadBodyScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void CHttpRequestMgr::sigUploadEyeSightScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void CHttpRequestMgr::sigTouristUsageRecordFinished(bool _t1, bool _t2, int _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void CHttpRequestMgr::sigCommitPrograssChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void CHttpRequestMgr::sigSyncLocalScore(QString _t1, QString _t2, short _t3, QString _t4, bool _t5)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)), const_cast<void*>(reinterpret_cast<const void*>(&_t5)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void CHttpRequestMgr::sigQueryHistoryScoreFinished(bool _t1, QVariant _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void CHttpRequestMgr::sigUploadMultiCommonScoreFinished(QVector<CMultiUploadRetInfo> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void CHttpRequestMgr::sigUploadMultiBodyScoreFinished(QVector<CMultiUploadRetInfo> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void CHttpRequestMgr::sigUploadMultiEyeSightScoreFinished(QVector<CMultiUploadRetInfo> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void CHttpRequestMgr::sigSendMultiHeartBeatFinished(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void CHttpRequestMgr::sigSyncMultiLocalScoresFinished(QVector<CMultiUploadRetInfo> _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void CHttpRequestMgr::insideSigInitMemberConnection()
{
    QMetaObject::activate(this, &staticMetaObject, 18, nullptr);
}

// SIGNAL 19
void CHttpRequestMgr::insideSigGetVideoUrls(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void CHttpRequestMgr::insideSigSendHeartBeat(int _t1, QString _t2, QString _t3, short _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void CHttpRequestMgr::insideSigSyncScoreStd()
{
    QMetaObject::activate(this, &staticMetaObject, 21, nullptr);
}

// SIGNAL 22
void CHttpRequestMgr::insideSigSyncUserInfo(QString _t1, int _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void CHttpRequestMgr::insideSigSyncClassInfo(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void CHttpRequestMgr::insideSigUserIdentify(QString _t1, int _t2, QString _t3, QString _t4)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)), const_cast<void*>(reinterpret_cast<const void*>(&_t4)) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void CHttpRequestMgr::insideSigUploadCommonScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void CHttpRequestMgr::insideSigUploadCommonScoreByVector(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void CHttpRequestMgr::insideSigUploadBodyScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void CHttpRequestMgr::insideSigUploadEyeSightScore(QVariant _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void CHttpRequestMgr::insideSigToutisUsageRecord(QString _t1, short _t2, QString _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 29, _a);
}

// SIGNAL 30
void CHttpRequestMgr::insideSigStartAuto()
{
    QMetaObject::activate(this, &staticMetaObject, 30, nullptr);
}

// SIGNAL 31
void CHttpRequestMgr::insideSigStartAutoUploadBodyScore()
{
    QMetaObject::activate(this, &staticMetaObject, 31, nullptr);
}

// SIGNAL 32
void CHttpRequestMgr::insideSigStartAutoEyesightScore()
{
    QMetaObject::activate(this, &staticMetaObject, 32, nullptr);
}

// SIGNAL 33
void CHttpRequestMgr::insideSigSyncLocalScore()
{
    QMetaObject::activate(this, &staticMetaObject, 33, nullptr);
}

// SIGNAL 34
void CHttpRequestMgr::insideSigQueryHistoryScore(QVariantMap _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 34, _a);
}

// SIGNAL 35
void CHttpRequestMgr::insideSigUploadMultiCommonScores(QVariantList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 35, _a);
}

// SIGNAL 36
void CHttpRequestMgr::insideSigUploadMultiBodyScores(QVariantList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 36, _a);
}

// SIGNAL 37
void CHttpRequestMgr::insideSigUploadMultiEyeSightScores(QVariantList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 37, _a);
}

// SIGNAL 38
void CHttpRequestMgr::insideSigSendMultiHeartBeat(QVariantList _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 38, _a);
}

// SIGNAL 39
void CHttpRequestMgr::insideSigSyncMultiLcoalScores(QVariantList _t1, QVariantList _t2, QVariantList _t3)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 39, _a);
}

// SIGNAL 40
void CHttpRequestMgr::insideSigStartGetServerToken(const QVariantMap _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 40, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
